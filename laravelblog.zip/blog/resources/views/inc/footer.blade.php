
<footer id="footer" class="text text-center">
	<p>Copyright &copy 2018 Eka Saputra</p>
</footer>
</body>
</html>