<?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="container">
		<div class="row">
			<legend>Laravel CRUD Application</legend>
			<?php if(session('info')): ?>
				<div class="alert alert-dismissible alert-success col-md-12">
				  <button type="button" class="close" data-dismiss="alert">&times;</button>
				  <strong>Info !</strong> <?php echo e(session('info')); ?></a>.
				</div>
			<?php endif; ?>
			<table class="table table-hover">
			  <thead class="table-primary">
			    <tr>
			      <th width="20px">ID</th>
			      <th>Title</th>
			      <th>Description</th>
			      <th width="200px">Action</th>
			    </tr>
			  </thead>
			  <tbody>
			  	<?php if(count($articles) > 0): ?>
			  		<?php $__currentLoopData = $articles->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				    <tr>
				      <th scope="row"><?php echo e($article->id); ?></th>
				      <td><?php echo e($article->title); ?></td>
				      <td><?php echo e($article->description); ?></td>
				      <td>
				      	<a href='<?php echo e(url("/read/{$article->id}")); ?>' class="badge badge-primary">Read</a> |
				      	<a href='<?php echo e(url("/update/{$article->id}")); ?>' class="badge badge-info">Update</a> |
				      	<a href='<?php echo e(url("/delete/{$article->id}")); ?>' class="badge badge-danger">Delete</a>
				      </td>
				    </tr>
			  		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			  	<?php endif; ?>
			  </tbody>
			</table> 
		</div>
	</div>

<?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>