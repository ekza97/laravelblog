<?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<form method="post" action="<?php echo e(url('/edit',array($articles->id))); ?>">
				<?php echo e(csrf_field()); ?>

				  <fieldset>
				    <legend>Laravel CRUD Application</legend>
				    <?php if(count($errors) >0): ?>
				    	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				    		<div class="alert alert-danger">
				    			<?php echo e($error); ?>

				    		</div>
				    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				    <?php endif; ?>
				    <div class="form-group">
				      <label for="exampleInputEmail1">Title</label>
				      <input type="text" class="form-control" name="title" placeholder="Title Post" value="<?php echo $articles->title; ?>">
				      <!-- <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small> -->
				    </div>
				    <div class="form-group">
				      <label for="exampleTextarea">Description</label>
				      <textarea class="form-control" name="description" rows="3" placeholder="Description Post"><?php echo $articles->description; ?></textarea>
				    </div>
				    <!-- <button type="reset" class="btn btn-warning" name="save">Cancel</button> -->
				    <button type="submit" class="btn btn-primary" name="save">Update</button>
				    <a href="<?php echo e(url('/')); ?>" class="btn btn-warning">Back</a>
				  </fieldset>
				</form>
			</div>
		</div>
	</div>
<?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>