<?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="jumbotron">
			<legend>Read Article</legend>
	  <h3 class="display-4"><?php echo e($articles->title); ?></h3>
	  <hr class="my-4">
	  <p><?php echo e($articles->description); ?></p>
	</div>
<?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>